package com.example;

public class App3 {
	public String Sample()
	{
		return "sample321A";
	}
}
