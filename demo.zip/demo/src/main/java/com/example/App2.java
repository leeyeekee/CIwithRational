package com.example;

public class App2 {
	public String Sample()
	{
		return "sample123";
	}
}
