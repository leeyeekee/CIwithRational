package com.example;

public class App {
	public String Sample()
    {
		App2 theObj = new App2();
		
        return "Hello Martin, here some sample text : " + theObj.Sample();
    }
}
