package com.example;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppTest {

	@Test
	public void test() {
		//added something
		//added some more line
	}

}
